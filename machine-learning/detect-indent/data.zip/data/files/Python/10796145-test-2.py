def foo(bar):
  if bar:
    return bar

>> foo('asdf') # returns 'asdf'
>> foo(False) # returns None