# Inside pry

compute.flavors.map { |f| [f.id, f.name] }