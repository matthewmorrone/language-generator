resources :pages do
  resources :images, controller: 'pages/images'
end

resources :images