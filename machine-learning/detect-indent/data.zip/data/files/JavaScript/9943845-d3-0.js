// in order to get random cool colors
d3.scale.category20().range()