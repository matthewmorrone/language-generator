YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "ActivationElliott",
        "ActivationElliottSymmetric",
        "ActivationLinear",
        "ActivationSigmoid",
        "ActivationTANH",
        "Anneal",
        "ArrayUtil",
        "BasicLayer",
        "BasicNetwork",
        "EGFILE",
        "Genetic",
        "LinearErrorFunction",
        "MathUtil",
        "PropagationTrainer",
        "ReadCSV",
        "SOM",
        "Swarm",
        "Vector",
        "VectorUtil"
    ],
    "modules": [
        "MYAPP"
    ],
    "allModules": [
        {
            "displayName": "MYAPP",
            "name": "MYAPP",
            "description": "This is the top level global variable that this example is stored under.\nFor this example, it is MYAPP."
        }
    ]
} };
});